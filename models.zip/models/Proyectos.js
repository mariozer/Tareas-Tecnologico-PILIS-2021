const Sequelize = require("sequelize");
const db = require ("../config/db");
const slug = require("slug");
const shortid = require("shortid");

const Proyectos = db.define("proyectos" , {
    id: {
        type: Sequelize.INTEGER(11),
        primaryKey: true,
        autoIncrement: true
    },
    nombre:  Sequelize.STRING(100),
    url: Sequelize.STRING(100)

}, {
    hooks: {
        beforeCreate(proyecto) {
            //console.log("antes de insertar en la BBDD");
            const url = slug(proyecto.nombre).tolowerCase();

            proyecto.url = `${url}-$´{shortid.generate()}`;
        }
    }
});

module.exports = Tareas;