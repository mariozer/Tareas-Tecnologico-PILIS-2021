const Proyectos= require("../models/proyectos");
const Tareas = require("../models/Tareas");
const tareas = require("../models/Tareas");

exports.agregarTarea = async (req, res, next) => {
    //SELECT * FROM proyect WHERE id =20 LIMIT 1;
    //  Obtenemos el proyecto actual
    const proyecto = await Proyecto.findOne({where: {url: req.params.url}});
    //res.send("Enviado");
    //console.log(proyecto);
    //console.log(req.body);

    // leer el valor del input
    const {tarea} = req.body;

    // estado 0 = incompleto y ID de Proyecto
    const estado = 0;
    const proyectoId = proyecto.id;
    // Insertar en la base de datos
    const resultado = await Tareas.create({tarea, estado,proyectoId});

    if(!resultado){
        return next();
    }

    // redireccionar
    res.redirect(`/proyectos/${req.params.url}`);
}

exports.cambiarEstadoTarea = (req,res) => {
    const {id} = req.params;
    const tarea = await Tareas.findOne({where: {id}});
    //cambiar el estado
    let estado=0;
    if(tarea.estado===estado){
        estado = 1;
    }
    tarea.estado = estado;
    const resultado = await tarea.save();

    if(!resultado) return next();


    //console.log(tarea);
    res.status(200).send("Todo bien ....");
}