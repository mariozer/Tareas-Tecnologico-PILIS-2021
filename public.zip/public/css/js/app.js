import proyectos from "./modulos/proyectos";
