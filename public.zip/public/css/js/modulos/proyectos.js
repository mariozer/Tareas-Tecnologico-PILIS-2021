import Swal from "sweetalert2";
import axios from "axio";

const btnEliminar = document.querySelector("#eliminar-proyecto");

if(btnEliminar){
    btnEliminar.addEventListener("clic", e => {
        const urlProyecto= e.target.dataset.proyectoUrl;
        //console.log(urlProyecto);
        //return;

        Swal.fire({
            title: "Estas Seguro Borrar este Proyecto?",
            text: "you wont be able to revert this !",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "si, Borrarlo !",
            cancelButtonText: "No Cancelar"
        }).then ((result) => {
            if (result.value)  {
                // enviar peticion a axios  codigo ascii 96 = ` ( Acento grave )
                const url =`${location.origin}/proyectos/${urlProyecto}`;
                //console.log(url);
                axios.delete(url, {params:{urlProyecto}})
                   .then(function(repuesta){
                       console.log(repuesta);
                       //return;
                       Swal.fire(
                        "Deleted",
                        repuesta.data, //"Su Archivo Ha sido borrado",
                        "success"
                    );
                    // redireccionar al inicio
                    setTimeout(() => {
                        window.location.href = "/"
        
                    }, 3000); 


                   })
                   .catch(() =>{
                       Swal.fire({
                           type: "error",
                           title: "Hubo un error",
                           text: "No se pudo eliminar el Proyecto"



                       })
                   })
                   

                     
             
            }
           
        })
             
    })

}

export default btnEliminar;
